Drawbridge.SalesforceAccountReconciliation

This web app allows users to delect 3 source data files -- from Salesforce, Preqin, and HFM, respectively -- and outputs 6 result files that perform exact and fuzzy string matches on organization names across the files. 

Build
Run dotnet build

Test
Run dotnet test to run unit tests. Run docker compose --profile test up --abort-on-container-exit to run integration tests. Docker setup instructions can be found here. After running, you must cleanup your environment with docker compose --profile test down.

If you want to only run dependencies and not spin up your container or run the Postman integration tests with newman, you can run docker compose --profile debug up. After running, you must cleanup your environment with docker compose --profile debug down.

Local configuration
If you want to override local configuration, you can do so by creating a config.json file in the Drawbridge.SalesforceAccountReconciliation folder.

